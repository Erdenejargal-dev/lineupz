import JoinLineForm from '@/components/JoinLineForm';

export default function JoinPage() {
  return (
    <>
      <div className="min-h-screen pt-20 bg-gray-50">
        <JoinLineForm />
      </div>
    </>
  );
}