import DashboardRouter from '@/components/DashboardRouter';

export default function DashboardPage() {
  return <DashboardRouter />;
}