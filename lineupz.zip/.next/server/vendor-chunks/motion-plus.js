"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
exports.id = "vendor-chunks/motion-plus";
exports.ids = ["vendor-chunks/motion-plus"];
exports.modules = {

/***/ "(ssr)/./node_modules/motion-plus/dist/es/index.mjs":
/*!****************************************************!*\
  !*** ./node_modules/motion-plus/dist/es/index.mjs ***!
  \****************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   splitText: () => (/* reexport safe */ motion_plus_dom__WEBPACK_IMPORTED_MODULE_0__.splitText)\n/* harmony export */ });\n/* harmony import */ var motion_plus_dom__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! motion-plus-dom */ \"(ssr)/./node_modules/motion-plus-dom/dist/es/index.mjs\");\n\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHNzcikvLi9ub2RlX21vZHVsZXMvbW90aW9uLXBsdXMvZGlzdC9lcy9pbmRleC5tanMiLCJtYXBwaW5ncyI6Ijs7Ozs7QUFBZ0MiLCJzb3VyY2VzIjpbIkM6XFxVc2Vyc1xcSGlUZWNoXFxEZXNrdG9wXFxsaW5ldXB6XFxub2RlX21vZHVsZXNcXG1vdGlvbi1wbHVzXFxkaXN0XFxlc1xcaW5kZXgubWpzIl0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCAqIGZyb20gJ21vdGlvbi1wbHVzLWRvbSc7XG4iXSwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbMF0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(ssr)/./node_modules/motion-plus/dist/es/index.mjs\n");

/***/ })

};
;